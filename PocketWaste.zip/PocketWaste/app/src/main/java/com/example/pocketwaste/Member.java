package com.example.pocketwaste;

public class Member {
private String Name;
private String Address;
private String  mDisplayDate;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getmDisplayDate() {
        return mDisplayDate;
    }

    public void setmDisplayDate(String mDisplayDate) {
        this.mDisplayDate = mDisplayDate;
    }

    public Member() {

    }
}
